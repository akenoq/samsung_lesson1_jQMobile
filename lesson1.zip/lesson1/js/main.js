( function () {
    window.addEventListener( 'tizenhwkey', function( ev ) {
        if( ev.keyName === "back" ) {
            var activePopup = document.querySelector( '.ui-popup-active' ),
                page = document.getElementsByClassName( 'ui-page-active' )[0],
                p = div[data-role]
                pageid = page ? page.id : "";

            if( pageid === "one" && !activePopup ) {
                try {
                    tizen.application.getCurrentApplication().exit();
                } catch (ignore) {
                }
            } else {
                window.history.back();
            }
        }
    } );
    
    $('#two').css({'color':'white','font':'30px'})
    
    $(function() {
    	
   // 	$('#img1').draggable();
    });

} () );



var startTime;
var checkTime;

//Initialize function
var init = function () {
	// TODO:: Do your initialization job
	console.log("init() called");

	// add eventListener for tizenhwkey
	document.addEventListener('tizenhwkey', function(e) {
		if(e.keyName == "back") {
			try {
				tizen.application.getCurrentApplication().exit();
			} catch (error) {
				console.error("getCurrentApplication(): " + error.message);
			}
		}
	});
};
// window.onload can work without <body onload="">
window.onload = init;

function startTime() {
	var today = new Date();
	var h = today.getHours();

	var m = today.getMinutes();
	var s = today.getSeconds();
	m = checkTime(m);
	s = checkTime(s);
	document.getElementById('divbutton1').innerHTML="Current time: " + h + ":" + m + ":" + s;
	var t = setTimeout(startTime, 250);
}

function checkTime(i) {
	if (i < 10) {
		i="0" + i;
	}
	return i;
}

function drawText() {
	var can = document.getElementById('can');
	var holst = can.getContext('2d');
	
	holst.clearRect(0,0,300,200);
	
	holst.lineWidth = 2;
	holst.strokeStyle = '#FFFFFF';
	holst.font = "Italic 40px Tahoma";
	holst.strokeText("Tizen",20,40);
		// буквы закрашены изнутри
	holst.fillStyle = '#000000';
	holst.font = "Italic 50px Arial";
	holst.fillText("JavaScript",20,90);
	
	holst.fillStyle = 'red';
	holst.font = "Italic 40px Tahoma";
	holst.fillText("HTML5",20,140);
	
	holst.fillStyle = 'blue';
	holst.font = "Italic 40px Tahoma";
	holst.fillText("HTML5",70,160);
}

function chessBoard() {
	var can = document.getElementById('can');
	var holst = can.getContext('2d');
	
	holst.clearRect(0,0,300,200);
	
	holst.strokeStyle = 'white';
	
	var x = 0;
	var y = 0;
	
	//holst.fillRect(x, y, 50, 50);
	
	var i;
	var j;
	
	var kol1 = "red";
	var kol2 = "yellow";
	
	for (i=0; i<=200; i+=50){
		for (j=0; j<=300; j+=100){
			holst.fillStyle = kol1;
			holst.fillRect(x, y, x+50, y+50);
			console.log(x);

			holst.fillStyle = kol2;
			holst.fillRect(x+50,y,x+100,y+50);
			console.log(x);
			x = j;
		}
		
		x = 0;
		y = i;
				
		var a = kol1;
		kol1 = kol2;
		kol2 = a;
	} 	
}

var xx = 0;
var yy = 0;

function runningSquare() {
	
	var start = Date.now(); // сохранить время начала

	var timer = setInterval(function() {
	  // вычислить сколько времени прошло с начала анимации
	  var timePassed = Date.now() - start;

	  if (timePassed >= 2000) {
	    clearInterval(timer); // конец через 2 секунды
	    xx = 0;
	    yy = 0;
	    return;
	  }

	  // рисует состояние анимации, соответствующее времени timePassed
	  f1();

	}, 20);
	
	//f1();
	
	//xx += 5;
	  
	//requestAnimationFrame(runningSquare);
}

function f1() {

	var can = document.getElementById('can');
	var holst = can.getContext('2d');
	
	holst.clearRect(0,0,300,200);
	
	holst.lineWidth = 5;
	
	holst.fillStyle = 'red';
	holst.strokeStyle = 'white';
	
	holst.fillRect(xx, yy, xx+50, yy+50);
	
	xx = xx + 1;
	
	if (xx > 300) {
	    xx = 0;
	}	
}

